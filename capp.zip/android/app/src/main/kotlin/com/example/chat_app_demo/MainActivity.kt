package com.example.chat_app_demo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
