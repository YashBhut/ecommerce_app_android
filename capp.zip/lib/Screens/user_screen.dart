import 'package:chat_app/Screens/chat_screen.dart';
import 'package:chat_app/Screens/sign_in_screen.dart';
import 'package:chat_app/models/ChatRoomModel.dart';
import 'package:chat_app/models/usermodel.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';
import 'package:get/get.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:intl/intl.dart';

import '../models/FirebaseHelper.dart';
import 'sign_in_screen.dart';

class User_Screen extends StatefulWidget {
  // final UserModel userModel;
  // final User firebaseUser;
  // final ChatRoomModel? chatroom;
  // final UserModel? userModel;

  const User_Screen({
    super.key,
    // this.chatroom,
    // this.userModel,
  });

  @override
  State<User_Screen> createState() => _User_ScreenState();
}

class _User_ScreenState extends State<User_Screen> {
  bool isClick = false;
  List<UserModel> datalist = [];
  List<UserModel> searchdata = [];
  TextEditingController search = TextEditingController();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    getUser();

    // _chatRef = FirebaseFirestore.instance
    //     .collection("chatrooms")
    //     .doc(widget.chatroom!.chatroomid)
    //     .collection("messages");
    // _chatRef.onValue.listen((event) {
    //   var snapshot = event.snapshot;
    //   int count = 0;
    //   snapshot.value.forEach((key, value) {
    //     if (value['messages'] == widget.userModel!.uid &&
    //         value['seen'] == false) {
    //       count++;
    //     }
    //   });
    //   setState(() {
    //     _unseenChatCount = count;
    //   });
    // });
  }

  UserModel? userModel;
  var user;
  var today = DateFormat.yMMMd().format(DateTime.now()); 
  var _chatRef;
  int _unseenChatCount = 0;

  getUser() async {
    user = await FirebaseFirestore.instance
        .collection('users')
        .doc(FirebaseAuth.instance.currentUser!.uid)
        .get();
    userModel = UserModel.fromMap(user.data());
    setState(() {});
    // print('Data of User: ${data?.data()}');
  }

  ChatRoomModel newMessage = ChatRoomModel(
    lasttime: DateTime.now(),
  );

  // LinearGradient linearGradient = const LinearGradient(
  //   colors: [
  //     Color(0xff39D2C0),
  //     Color(0xff4B39EF),
  //   ],
  //   stops: [0, 1],
  //   begin: AlignmentDirectional(1, -1),
  //   end: AlignmentDirectional(-1, 1),
  // );
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: const Color(0xFFF1F1F1),
      appBar: appBar(),
      body: userModel == null
          ? const Center(
              child: CircularProgressIndicator(),
            )
          : SafeArea(
              child: Container(
                padding: const EdgeInsets.all(15),
                child: StreamBuilder(
                  stream: FirebaseFirestore.instance
                      .collection("chatrooms")
                      .orderBy("lasttime", descending: true)
                      // .where(
                      //     "participants.${FirebaseAuth.instance.currentUser!.uid}",
                      //     isEqualTo: true)

                      // .orderBy(Timestamp.now().toDate().toString(),
                      //     descending: true)
                      .snapshots(),
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.active) {
                      QuerySnapshot chatRoomSnapshot =
                          snapshot.data as QuerySnapshot;
                      // print('data::::::::${newMessage.lastMessage}');
                      if (chatRoomSnapshot.docs.length != 0) {
                        print(
                            "data:: ${(snapshot.data!.docs[0]['lasttime']).toDate().toString()}");
                        // var Date1 = DateTime.parse(
                        //          .toString(),
                        //         );

                        // 12 Hour format:
// var list = chatRoomSnapshot.docs.where((val)=>
//                             val['participants']
                        //     "participants.${FirebaseAuth.instance.currentUser!.uid}",
                        // isEqualTo: true
                        // ).toList();
                        return ListView.builder(
                          physics: const BouncingScrollPhysics(),
                          itemCount: chatRoomSnapshot.docs.length,
                          itemBuilder: (context, index) {
                            ChatRoomModel chatRoomModel = ChatRoomModel.fromMap(
                                chatRoomSnapshot.docs[index].data()
                                    as Map<String, dynamic>);
                                    var lastdate = chatRoomModel.lasttime;
                                    var chattime = DateFormat.jm().format(lastdate!);
                                    var chatdate  = DateFormat.yMMMd().format(lastdate);
                                    var timeDate = chatdate == today ? chattime : chatdate; 
                            // var lastchattime = DateFormat('hh:mm a')
                            //     .format(chatRoomModel.lasttime!);
                            int unreadMessageCount = chatRoomModel.lastMessageSendBy ==  FirebaseAuth
                                                  .instance.currentUser!.uid ? 0 : chatRoomModel.unreadMessageCount ?? 0;
                            Map<String, dynamic> participants =
                                chatRoomModel.participants!;

                            List<String> participantKeys =
                                participants.keys.toList();
                            participantKeys
                                .remove(FirebaseAuth.instance.currentUser!.uid);
                            if (chatRoomModel.lastMessage != "") {
                              return FutureBuilder(
                                future: FirebaseHelper.getUserModelById(
                                    participantKeys[0]),
                                builder: (context, userData) {
                                  if (userData.connectionState ==
                                      ConnectionState.done) {
                                    if ((chatRoomModel.lastMessage.toString() !=
                                        "")) {
                                      UserModel targetUser =
                                          userData.data as UserModel;
                                      // bool uid=  chatRoomModel.participants?.containsKey(FirebaseAuth.instance.currentUser!.uid) as bool;
                                      bool user = (chatRoomModel.participants![
                                              FirebaseAuth
                                                  .instance.currentUser!.uid
                                                  .toString()] ==
                                          true);
                                      return user == false
                                          ? SizedBox()
                                          : ListTile(
                                              onTap: () {
                                                getUser();
                                                setState(() {
                                                  // chatRoomModel.lastMessage.toString();
                                                });
                                                Get.to(
                                                    Chat_Screen(
                                                        targetUser: targetUser,
                                                        chatroom: chatRoomModel,
                                                        userModel: userModel
                                                            as UserModel,
                                                        firebaseUser:
                                                            FirebaseAuth
                                                                    .instance
                                                                    .currentUser
                                                                as User),
                                                    arguments:
                                                        userModel as UserModel);
                                                // Navigator.push(
                                                //   context,
                                                //   MaterialPageRoute(builder: (context) {
                                                //     return ChatRoomPage(
                                                //       chatroom: chatRoomModel,
                                                //       firebaseUser: widget.firebaseUser,
                                                //       userModel: widget.userModel,
                                                //       targetUser: targetUser,
                                                //     );
                                                //   }),
                                                // );
                                              },
                                              leading: CircleAvatar(
                                                backgroundImage: NetworkImage(
                                                    targetUser.profilepic
                                                        .toString()),
                                                radius: 30,
                                                backgroundColor:
                                                    Colors.grey.shade300,
                                              ),
                                              title: Padding(
                                                padding: const EdgeInsets.only(
                                                    bottom: 6),
                                                child: Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceBetween,
                                                  children: [
                                                    Text(
                                                      targetUser.fullname
                                                          .toString(),
                                                      style: const TextStyle(
                                                          fontSize: 18),
                                                    ),
                                                    Text(
                                                      timeDate.toString(),
                                                      style: const TextStyle(
                                                        fontSize: 14,
                                                        color: Colors.grey,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              subtitle: Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceBetween,
                                                children: [
                                                  Text(
                                                    chatRoomModel.lastMessage
                                                        .toString(),
                                                    // chatRoomModel.lastMessageS.toString(),
                                                    style: const TextStyle(
                                                        fontSize: 16,
                                                        letterSpacing: 0.7,
                                                        color: Colors.grey),
                                                  ),
                                                  Container(
                                                      padding:
                                                          const EdgeInsets.only(
                                                              bottom: 2,
                                                              top: 2,
                                                              left: 8,
                                                              right: 8),
                                                      decoration:
                                                          const BoxDecoration(
                                                        gradient:
                                                            LinearGradient(
                                                          colors: [
                                                            Color.fromARGB(255,114, 102, 221),
                                                            Color(0xff39D2C0),
                                                          ],
                                                          stops: [0, 1],
                                                          begin:
                                                              AlignmentDirectional(
                                                                  -1, -1),
                                                          end:
                                                              AlignmentDirectional(
                                                                  -1, 1),
                                                        ),
                                                        borderRadius:
                                                            BorderRadius.all(
                                                          Radius.circular(5),
                                                        ),
                                                      ),
                                                      margin: const EdgeInsets
                                                              .symmetric(
                                                          vertical: 1),
                                                      child: Text(
                                                        '$unreadMessageCount',
                                                        style: TextStyle(
                                                            color:
                                                                Colors.white),
                                                      ))
                                                ],
                                              ));
                                    } else {
                                      return Container();
                                    }
                                  } else {
                                    return Container();
                                  }
                                },
                              );
                            }
                            // else{
                            //   return Column(
                            //     mainAxisAlignment: MainAxisAlignment.center,
                            //     children: [
                            //       SizedBox(
                            //         height: 250,
                            //       ),
                            //       Center(
                            //         child: Text("No Chagffdgts"),
                            //       ),
                            //     ],
                            //   );
                            // }
                          },
                        );
                      } else if (snapshot.hasError) {
                        return Center(
                          child: Text(snapshot.error.toString()),
                        );
                      } else {
                        return
                            //  SizedBox();
                            const Center(
                          child: Text("No Chats"),
                        );
                      }
                    } else {
                      return const Center(
                        child: CircularProgressIndicator(),
                      );
                    }
                  },
                ),
              ),
            ),
      // resizeToAvoidBottomInset: false,
      // floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      // floatingActionButton: Container(
      //   decoration: BoxDecoration(
      //     shape: BoxShape.circle,
      //     gradient: linearGradient,
      //   ),
      //   height: 70,
      //   width: 70,
      //   child: FloatingActionButton(
      //     backgroundColor: Colors.transparent,
      //     elevation: 0,
      //     onPressed: () {},
      //     child: const Icon(Icons.message),
      //   ),
      // ),
      // body: GestureDetector(
      //   onTap: () {
      //     FocusScope.of(context).unfocus();

      //     // search.clear();
      //   },
      //   child: Container(
      //     height: MediaQuery.of(context).size.height,
      //     // 200 -
      //     // AppBar().preferredSize.height,
      //     width: MediaQuery.of(context).size.width,
      //     child: StreamBuilder(
      //         stream:
      //             FirebaseFirestore.instance.collection('users').snapshots(),
      //         builder: (context, snapshot) {
      //           List<UserModel> list = [];
      //           if (snapshot.hasData) {
      //             list = [];
      //             final data = snapshot.data?.docs;
      //             list = data!.map((e) => UserModel.fromMap(e.data())).toList();
      //             print('Data : ${list[0]}');
      //             if (isClick == false) {
      //               datalist = list;
      //               searchdata = list;
      //             }
      //             return datalist == []
      //                 ? const Center(
      //                     child: Text("Data is not available"),
      //                   )
      //                 : search.text.trim().isEmpty && datalist.length - 1 == 0
      //                     ? const Center(
      //                         child: Text("Data is not available"),
      //                       )
      //                     : ListView.builder(
      //                         // shrinkWrap: true,
      //                         itemCount: datalist.length,
      //                         itemBuilder: (context, index) {
      //                           return datalist[index].uid ==
      //                                   FirebaseAuth.instance.currentUser!.uid
      //                               ? const SizedBox()
      //                               : Padding(
      //                                   padding: const EdgeInsets.symmetric(
      //                                       horizontal: 25,vertical: 7),
      //                                   // padding: const EdgeInsets.all(7.0),
      //                                   child: InkWell(
      //                                     onTap: () {
      //                                       Get.to(const Chat_Screen(),
      //                                           arguments: datalist[index]);
      //                                     },ihildren: [
      //                                           Column(
      //                                             children: [
      //                                               CircleAvatar(
      //                                                 backgroundImage:
      //                                                     Image.network(
      //                                                   datalist[index]
      //                                                       .profilepic
      //                                                       .toString(),
      //                                                 ).image,
      //                                                 radius: 30,
      //                                               ),
      //                                             ],
      //                                           ),
      //                                           const SizedBox(
      //                                             width: 10,
      //                                           ),
      //                                           Column(
      //                                             crossAxisAlignment:
      //                                                 CrossAxisAlignment.start,
      //                                             children: [
      //                                               Text(
      //                                                 datalist[index]
      //                                                     .fullname
      //                                                     .toString(),
      //                                                 style: TextStyle(
      //                                                     fontSize: 16),
      //                                               ),
      //                                               const SizedBox(
      //                                                 height: 8,
      //                                               ),
      //                                               Text(
      //                                                 datalist[index]
      //                                                     .email
      //                                                     .toString(),
      //                                                 style: TextStyle(
      //                                                     fontSize: 16,
      //                                                     letterSpacing: 0.7),
      //                                               ),
      //                                             ],
      //                                           )
      //                                         ],
      //                                       ),
      //                                     ),
      //                                   ),
      //                                 );
      //                         });
      //           } else {
      //             return Center(
      //               child: Text('Data is not fetch.'),
      //             );
      //           }
      //         }),
      //   ),
      // ),
      // bottomNavigationBar: bottombar(),
    );
  }

  AppBar appBar() {
    return AppBar(
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
          bottomLeft: Radius.circular(25.0),
          bottomRight: Radius.circular(25.0),
        ),
      ),
      elevation: 0,
      toolbarHeight: 125,
      backgroundColor: Colors.white,
      flexibleSpace: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            children: [
              const SizedBox(
                height: 10,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'Messages',
                    style: TextStyle(color: Colors.black, fontSize: 25),
                  ),
                  IconButton(
                    icon: const Icon(
                      Icons.more_vert_outlined,
                      color: Colors.black,
                    ),
                    onPressed: () {},
                  ),
                ],
              ),
              SizedBox(
                height: 50,
                child: TextField(
                  controller: search,
                  onChanged: (value) {
                    searchField(value.toString());
                    setState(() {});
                  },
                  onTap: () {
                    setState(() {
                      isClick = true;
                    });
                  },
                  cursorColor: Colors.grey,
                  decoration: InputDecoration(
                    contentPadding: const EdgeInsets.all(10),
                    fillColor: const Color(0xFFF2F3F2),
                    filled: true,
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(30),
                        borderSide: BorderSide.none),
                    hintText: 'Search By Names',
                    hintStyle:
                        const TextStyle(color: Color(0xFF7C7C7C), fontSize: 18),
                    prefixIcon: Container(
                      padding: const EdgeInsets.all(15),
                      width: 18,
                      child: const Icon(
                        Icons.search,
                        color: Colors.grey,
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(
                height: 10,
              ),
            ],
          ),
        ),
      ),
    );
  }

  void searchField(String value) {
    if (value.isEmpty) {
      datalist = searchdata;
      setState(() {});
    } else {
      datalist = searchdata
          .where((element) => element.fullname
              .toString()
              .replaceAll(' ', '')
              .toLowerCase()
              .contains(value.replaceAll(' ', '').toLowerCase()))
          .toList();
    }
    setState(() {});
  }
}
