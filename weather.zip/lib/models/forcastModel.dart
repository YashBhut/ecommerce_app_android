class Forcast {
  String? cityName;
  List<dynamic> list;

  Forcast({
    this.cityName,
    required this.list,
  });

  factory Forcast.fromjson(Map<String, dynamic> json) => Forcast(
      cityName: json["city"]['name'],
      list: json['list'].map((e) => CityData.fromJson(e)).toList());

  Map<String, dynamic> toJson() => {
        'name': cityName,
        'list': list.map((e) => e.toJson()).toList(),
      };
}

class CityData {
  String? temp;
  String? temp_min;
  String? temp_max;
  String? feels_like;
  String? wind;
  String? dt_txt;
  String? main;
  String? description;
  String? icon;

  CityData({
    this.temp,
    this.temp_min,
    this.temp_max,
    this.feels_like,
    this.wind,
    this.dt_txt,
    this.main,
    this.description,
    this.icon,
  });
  factory CityData.fromJson(Map<String, dynamic> json) => CityData(
      temp: json["main"]["temp"].toString(),
      temp_min: json["main"]["temp_min"].toString(),
      temp_max: json["main"]["temp_max"].toString(),
      feels_like: json["main"]["feels_like"].toString(),
      wind: json["wind"]["speed"].toString(),
      dt_txt: json["dt_txt"].toString(),
      main: json['weather'][0]['main'].toString(),
      description: json['weather'][0]['description'].toString(),
      icon: json['weather'][0]['icon'].toString(),
      // weather: (json['weather'] as List)
      //     .map((e) => Weatherforcast.fromJson(e))
      //     .toList()
          );

  Map<String, dynamic> toJson() => {
        'temp': temp,
        'temp_min': temp_min,
        'temp_max': temp_max,
        'feels_like': feels_like,
        'speed': wind,
        "dt_txt": dt_txt,
        'main': main,
        'description': description,
        'icon': icon,
        // 'weather': weather.map((e) => e.toJson()).toList(),
      };
}

// class Weatherforcast {
//   String? main;

//   Weatherforcast({
//     this.main,
//   });
//   Weatherforcast.fromJson(Map<String, dynamic> json) {
//     main = json['main'].toString();
//   }

//   Map<String, dynamic> toJson() => {
//         'main': main,
//       };
// }
