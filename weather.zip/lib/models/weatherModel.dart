class Weather{
  String?  cityName;
  String? visibility;
  double? temp;
  double? wind;
  double? temp_max;
  double? temp_min;
  String? feels_like;
  int? humidity;
  int? pressure;
  String? main;
  String? description;
  String? icon;

  Weather({
    this.cityName,
    this.visibility,
    this.temp,
    this.wind,
    this.temp_max,
    this.temp_min,
    this.feels_like,
    this.humidity,
    this.pressure, 
    this.main,
    this.description, 
    this.icon,
  });

  Weather.fromJson(Map<String,dynamic> json) {
    cityName = json["name"];
    visibility = json["visibility"].toString();
    temp = json["main"]["temp"];
    wind = json["wind"]["speed"];
    humidity = json["main"]["humidity"];
    temp_max = json["main"]["temp_max"];
    temp_min = json["main"]["temp_min"];
    feels_like = json["main"]["feels_like"].toString();
    pressure = json["main"]["pressure"];
    main = json["weather"][0]["main"];
    description = json["weather"][0]["description"];
    icon = json["weather"][0]["icon"];
  }

  Map<String, dynamic> toJson() => {
        'name' : cityName,
        'visibility' : visibility,
        'temp' : temp,
        'speed' : wind,
        'humidity' : humidity,
        'temp_max' : temp_max,
        'temp_max' : temp_max,
        'feels_like' : feels_like,
        'pressure' : pressure,
        'description' : description,
        'icon' : icon,
      };

}