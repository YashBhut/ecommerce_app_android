import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:weather_app/models/forcastModel.dart';
import 'package:weather_app/utils/constant.dart';
import 'package:weather_app/utils/weekday.dart';

import '../services/api.dart';

class ForcastScreen extends StatefulWidget {
  String weather;
  ForcastScreen({super.key, required this.weather});

  @override
  State<ForcastScreen> createState() => _ForcastScreenState();
}

class _ForcastScreenState extends State<ForcastScreen>
    with TickerProviderStateMixin {
  late AnimationController controller;
  late Animation<double> animation;
  Constants myConstants = Constants();

  TextEditingController citycontrollerforcast = TextEditingController();

  Forcast? _forcastData;
  bool isLoading = false;

  List<CityData> all = [];
  List today = [];
  List<CityData> tommorrow = [];
  List<CityData> remain = [];

  var argu = Get.arguments;

  String cloud = 'https://media.giphy.com/media/RpwupnbQE5nK6iRkYJ/giphy.gif';
  String clear =
      'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExYzEwYWY1YmUxYThmZjlmNjczYjYwOTYzZmJlZDE4NDlmYjRjMDQzNCZjdD1n/0Styincf6K2tvfjb5Q/giphy.gif';
  String haze = 'https://media.giphy.com/media/dgeIH5RPynA6Q/giphy.gif';
  String snow = 'https://media.giphy.com/media/BDucPOizdZ5AI/giphy.gif';
  String rain = 'https://media.giphy.com/media/5torEEM8QnR95Cqg11/giphy.gif';
  String def =
      'https://images.unsplash.com/photo-1514241516423-6c0a5e031aa2?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8c3VucmlzZXxlbnwwfHwwfHw%3D&w=1000&q=80';

  searchForcastCity(String cityName) async {
    var apiService = ApiService();
    print('cityname}');

    try {
      final forweather = await apiService.getForcast(cityName: cityName);

      setState(() {
        _forcastData = forweather;

        print('cityname:::::::${_forcastData!.cityName}');
      });
    } catch (e) {
      print('error ${e}');
      if (mounted) {
        setState(() {
          _forcastData = null;
        });
      }
    }

    var todayForecasts = [];

    final now = DateTime.now();
    final todayDate =
        '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';
    print('todayDate:::::::::${todayDate}');
    todayForecasts =
        _forcastData!.list.where((f) => f.dt_txt == todayDate).toList();
    print('today::::::::${todayForecasts}');
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    if (mounted) {
      setState(() {
        isLoading = true;
      });
    }

    if (argu != '') {
      citycontrollerforcast.text = argu;
      Timer.periodic(const Duration(milliseconds: 1000), (timer) {
        if (mounted) {
          setState(() {
            isLoading = false;
          });
        }
      });
      searchForcastCity(argu);
    } else {
      citycontrollerforcast.text = 'Surat';
      searchForcastCity(argu);
    }
    controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    );
    animation = CurvedAnimation(
      parent: controller,
      curve: Curves.easeOut,
    );
    controller.forward();
  }

  @override
  void dispose() {
    citycontrollerforcast.dispose();
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusManager.instance.primaryFocus?.unfocus(),
      child: Scaffold(
        body: Stack(
          children: [
            Container(
              height: MediaQuery.of(context).size.height,
              width: MediaQuery.of(context).size.width,
              child: Image.network(
                  _forcastData != null
                      ? (widget.weather == 'Clouds'
                          ? cloud
                          : widget.weather == 'Haze'
                              ? haze
                              : widget.weather == 'Smoke'
                                  ? haze
                                  : widget.weather == 'Snow'
                                      ? snow
                                      : widget.weather == 'Rain'
                                          ? rain
                                          : widget.weather == 'Clear'
                                              ? clear
                                              : def)
                      : def,
                  fit: BoxFit.fill),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              margin: const EdgeInsets.symmetric(vertical: 20),
              child: Column(
                children: [
                  SizedBox(
                    height: MediaQuery.of(context).size.height * 0.1,
                  ),
                  Row(
                    children: [
                      IconButton(
                        onPressed: () {
                          return Get.back();
                        },
                        icon: const Icon(Icons.chevron_left_rounded),
                        iconSize: 30,
                        color: Colors.white,
                      ),
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.only(right: 13),
                          child: SizedBox(
                            height: 50,
                            child: TextField(
                              controller: citycontrollerforcast,
                              onSubmitted: (_) {
                                setState(() {});

                                controller.forward();
                                searchForcastCity(citycontrollerforcast.text);
                              },
                              // onTap: () {
                              //   setState(() {});

                              //   searchForcastCity(citycontrollerforcast.text);
                              //   controller.forward();
                              // },
                              style: const TextStyle(fontSize: 20),
                              cursorColor: Colors.grey,
                              decoration: InputDecoration(
                                contentPadding: const EdgeInsets.all(10),
                                fillColor: const Color(0xFFF2F3F2),
                                filled: true,
                                border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10),
                                    borderSide: BorderSide.none),
                                hintText: 'Search City',
                                hintStyle: const TextStyle(
                                    color: Color(0xFF7C7C7C), fontSize: 18),
                                suffixIcon: Container(
                                  padding: const EdgeInsets.all(15),
                                  width: 18,
                                  child: const Icon(
                                    Icons.search,
                                    color: Colors.grey,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  isLoading == true
                      ? Container(
                          height: 500,
                          child: const Center(
                            child: CircularProgressIndicator(),
                          ),
                        )
                      : _forcastData == null
                          ? Column(
                              // height: MediaQuery.of(context).size.height * 0.7,
                              children: const [
                                  SizedBox(
                                    height: 250,
                                  ),
                                  // Center(
                                  //   child: Text(
                                  //     'Please Enter The City Name',
                                  //     style: TextStyle(
                                  //         color: Colors.white, fontSize: 20),
                                  //   ),
                                  // ),
                                ])
                          : Expanded(
                              child: ScaleTransition(
                                scale: animation,
                                child: ListView.builder(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 0, vertical: 15),
                                    itemCount: _forcastData!.list.length,
                                    shrinkWrap: true,
                                    itemBuilder: (context, index) {
                                      print(
                                          "length:::::${_forcastData!.list.length}");

                                      return Container(
                                        child: Column(
                                          children: [
                                            index == 0
                                                ? const Text(
                                                    "Today",
                                                    style: TextStyle(
                                                        color: Colors.white),
                                                  )
                                                : DateTime.parse(_forcastData!
                                                                .list[index]
                                                                .dt_txt)
                                                            .day ==
                                                        DateTime.parse(
                                                                _forcastData!
                                                                    .list[
                                                                        index -
                                                                            1]
                                                                    .dt_txt)
                                                            .day
                                                    ? const SizedBox()
                                                    : DateTime.parse(_forcastData!
                                                                    .list[index]
                                                                    .dt_txt)
                                                                .day ==
                                                            DateTime.now().day +
                                                                1
                                                        ? const Text(
                                                            "Tommorow",
                                                            style: TextStyle(
                                                                color: Colors
                                                                    .white),
                                                          )
                                                        : Text(
                                                            "${DateTime.parse(_forcastData!.list[index].dt_txt).weekdayName()}",
                                                            style:
                                                                const TextStyle(
                                                                    color: Colors
                                                                        .white),
                                                          ),
                                       

                                            ForcastData(index),
                                          ],
                                        ),
                                      );
                                    }),
                              ),
                            ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget ForcastData(i) {
    var myDate = DateTime.parse(_forcastData!.list[i].dt_txt);

    var currentDate = DateFormat('jm').format(myDate);
    var currentDay = DateFormat('E').format(myDate);

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 15),
          child: Container(
            width: MediaQuery.of(context).size.width,
            height: 160,
            decoration: BoxDecoration(
                color: myConstants.primaryColor,
                borderRadius: BorderRadius.circular(15),
                boxShadow: [
                  BoxShadow(
                    color: myConstants.primaryColor.withOpacity(.5),
                    offset: const Offset(0, 25),
                    blurRadius: 10,
                    spreadRadius: -12,
                  )
                ]),
            child: Stack(
              clipBehavior: Clip.none,
              children: [
                Positioned(
                  top: -80,
                  left: 0,
                  child: Image.network(
                    'https://openweathermap.org/img/wn/${_forcastData!.list[i].icon}.png',
                    height: 160,
                    width: 90,
                    fit: BoxFit.contain,
                  ),
                ),
                Positioned(
                  bottom: 35,
                  left: 20,
                  child: Text(
                    '${_forcastData!.list[i].main}',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                    ),
                  ),
                ),
                Positioned(
                  bottom: 15,
                  left: 20,
                  child: Text(
                    '${_forcastData!.list[i].description}',
                    style: const TextStyle(
                      color: Colors.white60,
                      fontSize: 18,
                    ),
                  ),
                ),
                Positioned(
                  top: 20,
                  right: 20,
                  child: Row(
                    children: [
                      Text(
                        '${currentDate}',
                        style: const TextStyle(
                          color: Colors.white60,
                          fontSize: 18,
                        ),
                      ),
                      const SizedBox(
                        width: 5,
                      ),
                      Text(
                        '${currentDay}',
                        style: const TextStyle(
                          color: Colors.white60,
                          fontSize: 18,
                        ),
                      ),
                    ],
                  ),
                ),
                Positioned(
                  top: 40,
                  right: 20,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(top: 4.0),
                        child: Text(
                          '${_forcastData!.list[i].temp} °C',
                          style: const TextStyle(
                            fontSize: 45,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Positioned(
                  right: 20,
                  bottom: 35,
                  child: Row(
                    children: [
                      const Icon(
                        Icons.arrow_upward_rounded,
                        color: Color.fromARGB(255, 171, 209, 248),
                      ),
                      Text(
                        '${_forcastData!.list[i].temp_max} °C',
                        style: const TextStyle(
                          fontSize: 18,
                          color: Color.fromARGB(255, 171, 209, 248),
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(
                        width: 10,
                      ),
                      const Icon(
                        Icons.arrow_downward_rounded,
                        color: Color.fromARGB(255, 171, 209, 248),
                      ),
                      Text(
                        '${_forcastData!.list[i].temp_min} °C',
                        style: const TextStyle(
                          fontSize: 18,
                          color: Color.fromARGB(255, 171, 209, 248),
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
                Positioned(
                  bottom: 15,
                  right: 20,
                  child: Row(
                    children: [
                      SvgPicture.asset(
                        'assets/images/temperature-feels-like.svg',
                        height: 20,
                        color: Colors.white60,
                      ),
                      const SizedBox(
                        width: 7,
                      ),
                      Text(
                        '${_forcastData!.list[i].feels_like} °C',
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          // color: Color.fromARGB(255, 171, 209, 248),
                          color: Colors.white60,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
