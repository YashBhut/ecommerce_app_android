import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_navigation/get_navigation.dart';
import 'package:weather_app/models/weatherModel.dart';
import 'package:weather_app/screens/forcast.dart';
import 'package:weather_app/services/api.dart';
import 'package:weather_app/utils/constant.dart';
import 'package:weather_app/utils/widgets/weather_item.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with TickerProviderStateMixin {
  late AnimationController controller;
  late Animation<double> animation;
  Constants myConstants = Constants();

  TextEditingController citycontroller = TextEditingController(text: 'Surat');

  Weather? _weatherData;
  bool isLoading = false;

  searchCity(String cityName) async {
    var apiService = ApiService();

    try {
      final weather = await apiService.getWeather(cityName: cityName);

      setState(() {
        if (mounted) {
          isLoading = true;
        }
        _weatherData = weather;
        if (mounted) {
          isLoading = false;
        }
        print('cityname:::::::${cityName}');
      });
    } catch (e) {
      setState(() {
        _weatherData = null;
      });
    }
  }

  String cloud = 'https://media.giphy.com/media/RpwupnbQE5nK6iRkYJ/giphy.gif';
  String clear =
      'https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExYzEwYWY1YmUxYThmZjlmNjczYjYwOTYzZmJlZDE4NDlmYjRjMDQzNCZjdD1n/0Styincf6K2tvfjb5Q/giphy.gif';
  String haze = 'https://media.giphy.com/media/dgeIH5RPynA6Q/giphy.gif';
  String snow = 'https://media.giphy.com/media/BDucPOizdZ5AI/giphy.gif';
  String rain = 'https://media.giphy.com/media/5torEEM8QnR95Cqg11/giphy.gif';
  String def =
      'https://images.unsplash.com/photo-1514241516423-6c0a5e031aa2?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8c3VucmlzZXxlbnwwfHwwfHw%3D&w=1000&q=80';

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    searchCity('Surat');
    controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    );
    animation = CurvedAnimation(
      parent: controller,
      curve: Curves.easeOut,
    );
    controller.forward();
  }

  @override
  void dispose() {
    citycontroller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusManager.instance.primaryFocus?.unfocus(),
      child: Scaffold(
        // backgroundColor: Colors.white,
        body: SingleChildScrollView(
          child: Stack(children: [
            Container(
              height: MediaQuery.of(context).size.height,
              width: MediaQuery.of(context).size.width,
              child: Image.network(
                  _weatherData != null
                      ? (_weatherData!.main == 'Clouds'
                          ? cloud
                          : _weatherData!.main == 'Haze'
                              ? haze
                              : _weatherData!.main == 'Smoke'
                                  ? haze
                                  : _weatherData!.main == 'Snow'
                                      ? snow
                                      : _weatherData!.main == 'Rain'
                                          ? rain
                                          : _weatherData!.main == 'Clear'
                                              ? clear
                                              : def)
                      : def,
                  fit: BoxFit.fill),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              margin: const EdgeInsets.symmetric(vertical: 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    height: MediaQuery.of(context).size.height * 0.1,
                  ),
                  Row(children: [
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.only(left: 13),
                        child: SizedBox(
                          height: 50,
                          child: TextField(
                            controller: citycontroller,
                            onSubmitted: (_) {
                              setState(() {});
                              searchCity(citycontroller.text);
                            },
                            cursorColor: Colors.grey,
                            style: const TextStyle(fontSize: 20),
                            decoration: InputDecoration(
                              contentPadding: const EdgeInsets.all(10),
                              fillColor: const Color(0xFFF2F3F2),
                              filled: true,
                              border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10),
                                  borderSide: BorderSide.none),
                              hintText: 'Search City',
                              hintStyle: const TextStyle(
                                  color: Color(0xFF7C7C7C), fontSize: 18),
                              prefixIcon: Container(
                                padding: const EdgeInsets.all(15),
                                width: 18,
                                child: const Icon(
                                  Icons.search,
                                  color: Colors.grey,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    // const SizedBox(
                    //   width: 10,
                    // ),
                    IconButton(
                      onPressed: () {
                        FocusScope.of(context).unfocus();
                        Future.delayed(Duration(milliseconds: 1000));
                        Get.to(
                            ForcastScreen(
                                weather: _weatherData != null
                                    ? _weatherData!.main.toString()
                                    : 'Clouds'),
                            arguments: citycontroller.text.trim());
                      },
                      icon: Icon(Icons.av_timer_rounded),
                      color: Colors.white,
                      iconSize: 40,
                    ),
                  ]),
                  isLoading == true
                      ? Container(
                          height: 500,
                          child: const Center(
                            child: CircularProgressIndicator(),
                          ),
                        )
                      : (_weatherData != null)
                          ? CurrenData()
                          : Center(
                              child: Container(
                          height: 500,
                          child: const Center(
                            child: CircularProgressIndicator(),
                          ),
                        ),
                            )
                ],
              ),
            ),
          ]),
        ),
      ),
    );
  }

  Widget CurrenData() {
    return Container(
      padding: const EdgeInsets.all(20),
      child: ScaleTransition(
        scale: animation,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '${_weatherData!.cityName}',
              style: const TextStyle(
                fontWeight: FontWeight.w900,
                fontSize: 30.0,
                color: Colors.white,
              ),
            ),
            const SizedBox(
              height: 50,
            ),
            Container(
              width: MediaQuery.of(context).size.width,
              height: 200,
              decoration: BoxDecoration(
                  color: myConstants.primaryColor,
                  borderRadius: BorderRadius.circular(15),
                  boxShadow: [
                    BoxShadow(
                      color: myConstants.primaryColor.withOpacity(.5),
                      offset: const Offset(0, 25),
                      blurRadius: 10,
                      spreadRadius: -12,
                    )
                  ]),
              child: Stack(
                clipBehavior: Clip.none,
                children: [
                  Positioned(
                    top: -80,
                    left: 0,
                    child: Image.network(
                      'https://openweathermap.org/img/wn/${_weatherData!.icon}.png',
                      height: 160,
                      width: 110,
                      fit: BoxFit.contain,
                    ),
                  ),
                  Positioned(
                    bottom: 35,
                    left: 20,
                    child: Text(
                      '${_weatherData!.main}',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                      ),
                    ),
                  ),
                  Positioned(
                    bottom: 15,
                    left: 20,
                    child: Text(
                      '${_weatherData!.description}',
                      style: const TextStyle(
                        color: Colors.white60,
                        fontSize: 18,
                      ),
                    ),
                  ),
                  Positioned(
                    right: 20,
                    top: 90,
                    child: Row(
                      children: [
                        const Icon(
                          Icons.arrow_upward_rounded,
                          color: Color.fromARGB(255, 171, 209, 248),
                        ),
                        Text(
                          '${_weatherData!.temp_max} °C',
                          style: const TextStyle(
                            fontSize: 18,
                            color: Color.fromARGB(255, 171, 209, 248),
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(
                          width: 10,
                        ),
                        const Icon(
                          Icons.arrow_downward_rounded,
                          color: Color.fromARGB(255, 171, 209, 248),
                        ),
                        Text(
                          '${_weatherData!.temp_min} °C',
                          style: const TextStyle(
                            fontSize: 18,
                            color: Color.fromARGB(255, 171, 209, 248),
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Positioned(
                    top: 120,
                    right: 20,
                    child: Row(
                      children: [
                        SvgPicture.asset(
                          'assets/images/temperature-feels-like.svg',
                          height: 20,
                          color: Colors.white60,
                        ),
                        const SizedBox(
                          width: 7,
                        ),
                        Text(
                          '${_weatherData!.feels_like} °C',
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            // color: Color.fromARGB(255, 171, 209, 248),
                            color: Colors.white60,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Positioned(
                    top: 20,
                    right: 20,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(top: 4.0),
                          child: Text(
                            '${_weatherData!.temp} °C',
                            style: const TextStyle(
                              fontSize: 55,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(
              height: 40,
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 60),
              child: ScaleTransition(
                scale: animation,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        weatherItem(
                          text: 'Wind',
                          value: "${_weatherData!.wind}",
                          weather: _weatherData!.main.toString(),
                          unit: ' km/h',
                          imageUrl: 'assets/images/windspeed.png',
                        ),
                        weatherItem(
                            text: 'Humidity',
                            weather: _weatherData!.main.toString(),
                            value: '${_weatherData!.humidity}',
                            unit: ' %',
                            imageUrl: 'assets/images/humidity.png'),
                      ],
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        weatherItem(
                          text: 'Pressure',
                          value: '${_weatherData!.pressure}',
                          weather: _weatherData!.main.toString(),
                          unit: ' hPa',
                          imageUrl: 'assets/images/pressure.png',
                        ),
                        weatherItem(
                          text: 'Visibility',
                          weather: _weatherData!.main.toString(),
                          value: (double.parse(
                                      _weatherData!.visibility.toString()) /
                                  1000)
                              .toString(),
                          unit: ' Km',
                          imageUrl: 'assets/images/low-visibility.png',
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
