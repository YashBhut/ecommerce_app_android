import 'dart:convert' as convert;

import 'package:http/http.dart' as http;
import 'package:weather_app/models/forcastModel.dart';
import 'package:weather_app/models/weatherModel.dart';

class ApiService {
  Future<Weather> getWeather({required String cityName}) async {
    final apiKey = 'e01d3843617e60c3fed50e169973b4b9';
    var url = Uri.parse(
        "https://api.openweathermap.org/data/2.5/weather?q=$cityName&appid=$apiKey&units=metric");
    var response = await http.get(url);
    if (response.statusCode == 200) {
      final citylocdata = convert.jsonDecode(response.body);
      return Weather.fromJson(citylocdata);
    } else {
      throw response.body;
    }
  }

  Future<Forcast> getForcast({required String cityName}) async {
    final apiKey = 'e01d3843617e60c3fed50e169973b4b9';
    var url = Uri.parse(
        "https://api.openweathermap.org/data/2.5/forecast?q=$cityName&appid=$apiKey&units=metric");
    var response = await http.get(url);
    if (response.statusCode == 200) {
      print('enter');
      final data = convert.jsonDecode(response.body);
      print('forcast:::::$data');

      Forcast forcastdata = Forcast.fromjson(data);
      print('forcastssssssssss:::::${forcastdata.list}');

        

      return forcastdata;
    } else {
      throw response.body;
    }
  }
}
