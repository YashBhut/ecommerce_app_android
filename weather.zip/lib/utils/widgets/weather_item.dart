
import 'package:flutter/material.dart';
import 'package:weather_app/models/weatherModel.dart';

class weatherItem extends StatelessWidget {
  const weatherItem({
    Key? key,
   required this.weather,
    required this.value, required this.text, required this.unit, required this.imageUrl,
  }) : super(key: key);

  final String value;
  final String text;
  final String unit;
  final String imageUrl;
  final String weather ;
  

  @override
  Widget build(BuildContext context) {

    
    return Column(
      children: [
        Text(text, style:  TextStyle(
          color: weather == 'Rain' || weather == 'Haze' || weather == 'Smoke'? Colors.white : Colors.black54,
          letterSpacing: 0.5,
          fontWeight: FontWeight.w800,fontSize: 15
        ),),
        const SizedBox(
          height: 8,
        ),
        Container(
          padding: const EdgeInsets.all(10.0),
          height: 60,
          width: 60,
          decoration: const BoxDecoration(
            color: Color(0xffE0E8FB),
            borderRadius: BorderRadius.all(Radius.circular(15)),
          ),
          child: Image.asset(imageUrl),
        ),
        const SizedBox(
          height: 8,
        ),
        Text(value.toString() + unit, style:  TextStyle(
          color:weather == 'Rain'|| weather == 'Haze'||weather == 'Smoke'?Colors.white:Colors.black54,
          fontWeight: FontWeight.w800,
        ),)
      ],
    );
  }
}